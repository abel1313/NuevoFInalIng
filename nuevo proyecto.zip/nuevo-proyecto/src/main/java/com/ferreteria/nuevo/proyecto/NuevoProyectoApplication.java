package com.ferreteria.nuevo.proyecto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NuevoProyectoApplication {

	public static void main(String[] args) {
		SpringApplication.run(NuevoProyectoApplication.class, args);
	}

}
