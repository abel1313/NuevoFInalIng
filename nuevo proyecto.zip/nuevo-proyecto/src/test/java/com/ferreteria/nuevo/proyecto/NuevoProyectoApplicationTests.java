package com.ferreteria.nuevo.proyecto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NuevoProyectoApplicationTests {

	@Test
	void contextLoads() {
	}

}
